package com.example.a2019_seg2105_project.ui.clinicApp.navigation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AdminMainViewModel extends ViewModel {

    public AdminMainViewModel() {

    }

}
